#!/usr/bin/env python3
"""Reels re-voice pipeline helper. Runs inside the Higgsfield sandbox (sandbox_exec):
ffmpeg + python3 + faster-whisper are preinstalled there.

Subcommands
  inspect  <video_url_or_path> <part 1|2>
      Transcribe the clip, compare it with the expected script, and write a contact
      sheet (inspect_partN.jpg) to look at with image_paths. Prints a JSON verdict.
  prep     <part1_url> <part2_url>
      Writes head_3s8.mp4 (first 3.8 s of part 1, 30 fps, for remove_background)
      and speaker_ref.jpg (talking-head frame from part 2, reference for the
      editor-screen inserts).
  assemble <config.json>
      Builds the final reel. See CONFIG below.

CONFIG (all values are https URLs or local paths)
  {
    "part1":        Genjutsu motion-control result, part 1 (has the new voice),
    "part2":        Genjutsu motion-control result, part 2,
    "head_cutout":  remove_background result for head_3s8.mp4 (person on black),
    "insert_A":     Genjutsu replace result for insert_A_editor_template.mp4,
    "insert_B":     Genjutsu replace result for insert_B_editor_template.mp4,
    "insert_A_template", "insert_B_template": the two templates (optional but
                    recommended: used to detect and undo any time shift Genjutsu adds),
    "graphics":     graphics_color_alpha_stacked.mp4,
    "word_timings": original_word_timings.json,
    "out":          output file name, e.g. "final_reel.mp4"
  }
"""
import json, os, re, subprocess, sys, statistics, urllib.request

WORK = os.path.expanduser("~/reel_work")
os.makedirs(WORK, exist_ok=True)

# ---- fixed facts about the graphics timeline (seconds / frames at 30 fps) ----
GFX_FPS = 30
ORANGE_ON, ORANGE_OFF = 0.23, 3.6          # orange full-screen card
ORANGE_RGB = "0xFF7705"
LAND_CAPTION_GFX = 25.10                    # first frame of the "land with the edits" caption
CUT1_MIN = 24.16                            # earliest graphics cut (user-approved; insert B and its exit are over)
CUT1_FALLBACK = 24.16                       # the cut chosen by hand for the reference reel
PART2_OFFSET_FALLBACK = 27.64               # gfx time of part 2 local 0 in the reference reel
INSERT_A = dict(start_frame=134, frames=36, x=160, y=1185, w=760, h=430)
INSERT_B = dict(start_frame=645, frames=70, x=250, y=0, w=600, h=430)

SCRIPT = {
    1: ("Fable 5.2 just dropped and it edited this entire video in one click. You don't need "
        "After Effects or Premiere Pro, nothing. The captions, the cuts, the effects were all done "
        "with just Claude and Higgsfield. And right now, Higgsfield is giving you three days of "
        "unlimited access to all models for free. I can make screen recordings appear as I explain, "
        "and even the sound effects land with the edits. It's called Shorts Studio"),
    2: ("powered by Higgsfield, right inside your Claude. You can just upload your best performing "
        "video as a reference, or start with a proven template from Higgsfield. Type slash shorts in "
        "Claude, give it a topic, and show it the style you want. It creates the visuals for you, the "
        "images, the supporting footage, all built around your story. Editing this kind of video would "
        "take hours or even days with Adobe. I didn't even film the video you're watching right now. "
        "I just uploaded my photo and a script. Pretty good, isn't it? Comment short and I'll send you the link."),
}


def sh(cmd):
    print("+", " ".join(cmd)[:300], flush=True)
    subprocess.run(cmd, check=True)


def fetch(src, name):
    if not re.match(r"https?://", src):
        return os.path.abspath(src)
    dst = os.path.join(WORK, name)
    if not os.path.exists(dst):
        sh(["curl", "-fsSL", "-o", dst, src])
    return dst


def duration(path):
    out = subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                                   "-of", "csv=p=0", path]).decode().strip()
    return float(out)


def norm(w):
    return re.sub(r"[^a-z0-9]", "", w.lower())


_model = None
def words_of(path):
    global _model
    from faster_whisper import WhisperModel
    if _model is None:
        _model = WhisperModel("small", device="cpu", compute_type="int8")
    segs, _ = _model.transcribe(path, language="en", word_timestamps=True,
                                condition_on_previous_text=False)
    out = []
    for s in segs:
        for w in s.words:
            n = norm(w.word)
            if n:
                out.append((n, float(w.start), float(w.end)))
    return out


def sim_words(a, b):
    # alias the brand names Whisper usually mishears
    alias = {"cloud": "claude", "klaus": "claude", "clod": "claude",
             "higgsfield": "higgsfield", "hicksfield": "higgsfield", "higgisfield": "higgsfield",
             "hippiesfield": "higgsfield", "geeksfield": "higgsfield", "short": "shorts"}
    return alias.get(a, a) == alias.get(b, b)


# ------------------------------------------------------------------ inspect
def cmd_inspect(src, part):
    part = int(part)
    path = fetch(src, f"inspect_part{part}.mp4")
    got = words_of(path)
    exp = [norm(w) for w in SCRIPT[part].split() if norm(w)]
    # greedy alignment: which expected words were found, which got words are extra
    j, matched, extra = 0, 0, []
    for w, s, e in got:
        hit = False
        for k in range(j, min(j + 4, len(exp))):
            if sim_words(w, exp[k]):
                j, hit = k + 1, True
                matched += 1
                break
        if not hit:
            extra.append((w, round(s, 2)))
    tail_extra = [x for x in extra if part == 1 and got and x[1] > got[-1][1] - 3]
    sheet = os.path.join(os.path.expanduser("~"), f"inspect_part{part}.jpg")
    sh(["ffmpeg", "-v", "error", "-y", "-i", path, "-vf", "fps=1/2,scale=150:-1,tile=8x2",
        "-frames:v", "1", "-q:v", "4", sheet])
    verdict = {
        "part": part,
        "duration": round(duration(path), 2),
        "transcript": " ".join(w for w, _, _ in got),
        "expected_words": len(exp),
        "matched_words": matched,
        "coverage": round(matched / len(exp), 3),
        "extra_words": extra[:40],
        "contact_sheet": sheet,
        "hint": ("coverage >= 0.9 is good. Extra words in the middle = model ad-libbed (regenerate if many). "
                 "Extra words after the last scripted word of part 1 are cut automatically by assemble. "
                 "Look at the contact sheet: there must be NO captions, titles or UI overlays."),
    }
    print(json.dumps(verdict, ensure_ascii=False, indent=1))


# ------------------------------------------------------------------ prep
def cmd_prep(p1, p2):
    a = fetch(p1, "part1.mp4")
    b = fetch(p2, "part2.mp4")
    home = os.path.expanduser("~")
    sh(["ffmpeg", "-v", "error", "-y", "-i", a, "-t", "3.8", "-an", "-vf", "fps=30", "-c:v", "libx264",
        "-crf", "14", "-pix_fmt", "yuv420p", f"{home}/head_3s8.mp4"])
    t = min(9.0, duration(b) / 2)
    sh(["ffmpeg", "-v", "error", "-y", "-ss", str(t), "-i", b, "-frames:v", "1", "-q:v", "2",
        f"{home}/speaker_ref.jpg"])
    print(json.dumps({"head_clip": f"{home}/head_3s8.mp4", "speaker_ref": f"{home}/speaker_ref.jpg",
                      "speaker_ref_time": t}))


# ------------------------------------------------------------------ assemble
def gray_frames(path, n, w=96, h=54):
    import numpy as np
    raw = subprocess.check_output(["ffmpeg", "-v", "error", "-i", path, "-vf",
                                   f"fps=30,scale={w}:{h},format=gray", "-frames:v", str(n),
                                   "-f", "rawvideo", "-"])
    return np.frombuffer(raw, np.uint8).reshape(-1, h, w).astype(float)


def insert_shift(result, template, frames, max_shift=8):
    """Frames by which the Genjutsu result is late (+) or early (-) vs the template."""
    import numpy as np
    r = gray_frames(result, frames + 2 * max_shift)
    t = gray_frames(template, frames + 2 * max_shift)
    best, best_k = None, 0
    for k in range(-max_shift, max_shift + 1):
        idx = [i for i in range(frames) if 0 <= i + k < len(r) and i < len(t)]
        if len(idx) < frames // 2:
            continue
        d = float(np.mean([np.abs(r[i + k] - t[i]).mean() for i in idx]))
        if best is None or d < best - 1e-6 or (abs(d - best) < 1e-6 and abs(k) < abs(best_k)):
            best, best_k = d, k
    return best_k


def cmd_assemble(cfg_path):
    cfg = json.load(open(cfg_path))
    p1 = fetch(cfg["part1"], "part1.mp4")
    p2 = fetch(cfg["part2"], "part2.mp4")
    cut = fetch(cfg["head_cutout"], "head_cutout.mp4")
    iA = fetch(cfg["insert_A"], "insert_A.mp4")
    iB = fetch(cfg["insert_B"], "insert_B.mp4")
    gfx = fetch(cfg["graphics"], "graphics.mp4")
    wt = fetch(cfg["word_timings"], "original_word_timings.json")
    out = os.path.join(os.path.expanduser("~"), cfg.get("out", "final_reel.mp4"))
    orig = [(x["w"], x["s"]) for x in json.load(open(wt))["words"]]

    d1, d2 = duration(p1), duration(p2)
    w1, w2 = words_of(p1), words_of(p2)

    # end of part 1 = end of "Studio" (anything after it is a model ad-lib)
    studio = [e for w, s, e in w1 if w == "studio"]
    p1_end = min(d1, studio[-1] + 0.06) if studio else d1
    # "land with the edits": jump the graphics so the caption starts here
    land = [s for w, s, e in w1 if w == "land" and s > 15]
    cut1 = min(max(land[0], CUT1_MIN), LAND_CAPTION_GFX) if land else CUT1_FALLBACK
    cut1 = min(cut1, p1_end)
    # part 2 placement on the graphics timeline: median word offset vs original speech
    o2 = [(w, s) for w, s in orig if s > 27.5]
    offs, j = [], 0
    for w, s, e in w2:
        for k in range(j, min(j + 6, len(o2))):
            if sim_words(w, o2[k][0]):
                offs.append(o2[k][1] - s)
                j = k + 1
                break
    g3 = statistics.median(offs) if len(offs) >= 10 else PART2_OFFSET_FALLBACK
    g2_dur = max(0.0, p1_end - cut1)
    total = p1_end + d2

    # editor-screen inserts: if Genjutsu shifted them in time, find the shift by
    # comparing with the templates and compensate (normally 0)
    shiftA = shiftB = 0
    if cfg.get("insert_A_template"):
        shiftA = insert_shift(iA, fetch(cfg["insert_A_template"], "insert_A_template.mp4"), INSERT_A["frames"])
    if cfg.get("insert_B_template"):
        shiftB = insert_shift(iB, fetch(cfg["insert_B_template"], "insert_B_template.mp4"), INSERT_B["frames"])
    A = dict(INSERT_A, src_start=max(shiftA, 0), pad=max(-shiftA, 0))
    B = dict(INSERT_B, src_start=max(shiftB, 0), pad=max(-shiftB, 0))
    fps = GFX_FPS
    fc = f"""
[0:v]fps=30,trim=0:{p1_end:.3f},setpts=PTS-STARTPTS,format=yuv420p,setsar=1[v1];
[1:v]fps=30,setpts=PTS-STARTPTS,format=yuv420p,setsar=1[v2];
[v1][v2]concat=n=2:v=1:a=0[base];
[0:a]aresample=48000,atrim=0:{p1_end:.3f},asetpts=PTS-STARTPTS,afade=t=out:st={max(0, p1_end-0.04):.3f}:d=0.04[va1];
[1:a]aresample=48000,asetpts=PTS-STARTPTS,afade=t=in:d=0.02[va2];
[va1][va2]concat=n=2:v=0:a=1[voice];
[5:v]split=2[gtop][gbot];
[gtop]crop=1080:1920:0:0,format=yuv444p[gcol];
[gbot]crop=1080:1920:0:1920,format=gray[galpha];
[gcol][galpha]alphamerge,format=yuva444p,split=3[gm][ga][gb];
[ga]trim=start_frame={A['start_frame']}:end_frame={A['start_frame']+A['frames']},setpts=PTS-STARTPTS,crop={A['w']}:{A['h']}:{A['x']}:{A['y']},alphaextract[aA];
[3:v]fps=30,tpad=start_mode=clone:start={A['pad']},trim=start_frame={A['src_start']}:end_frame={A['src_start']+A['frames']},setpts=PTS-STARTPTS,scale={A['w']}:{A['h']}:flags=lanczos,format=yuv444p[cA];
[cA][aA]alphamerge,setpts=PTS+{A['start_frame']}/{fps}/TB[pA];
[gb]trim=start_frame={B['start_frame']}:end_frame={B['start_frame']+B['frames']},setpts=PTS-STARTPTS,crop={B['w']}:{B['h']}:{B['x']}:{B['y']},alphaextract[aB];
[4:v]fps=30,tpad=start_mode=clone:start={B['pad']},trim=start_frame={B['src_start']}:end_frame={B['src_start']+B['frames']},setpts=PTS-STARTPTS,scale={B['w']}:{B['h']}:flags=lanczos,format=yuv444p[cB];
[cB][aB]alphamerge,setpts=PTS+{B['start_frame']}/{fps}/TB[pB];
[gm][pA]overlay={A['x']}:{A['y']}:eof_action=pass:format=yuv444[gp1];
[gp1][pB]overlay={B['x']}:{B['y']}:eof_action=pass:format=yuv444,format=yuva444p,split=3[g1i][g2i][g3i];
[g1i]trim=0:{cut1:.3f},setpts=PTS-STARTPTS[g1];
[g2i]trim={LAND_CAPTION_GFX:.3f}:{LAND_CAPTION_GFX+g2_dur:.3f},setpts=PTS-STARTPTS[g2];
[g3i]trim=start={g3:.3f},setpts=PTS-STARTPTS[g3];
[g1][g2][g3]concat=n=3:v=1:a=0,split=3[g][gt0][ga0];
[gt0]format=rgba,split[gk0][grgb];
[gk0]colorkey={ORANGE_RGB}:0.13:0.06,alphaextract[ka];
[ga0]format=rgba,alphaextract[oa];
[ka][oa]blend=all_mode=darken[ma];
[grgb][ma]alphamerge[gt];
[5:a]aresample=48000,asplit=3[m1i][m2i][m3i];
[m1i]atrim=0:{cut1:.3f},asetpts=PTS-STARTPTS,afade=t=out:st={max(0, cut1-0.03):.3f}:d=0.03[m1];
[m2i]atrim={LAND_CAPTION_GFX:.3f}:{LAND_CAPTION_GFX+g2_dur:.3f},asetpts=PTS-STARTPTS,afade=t=in:d=0.03[m2];
[m3i]atrim=start={g3:.3f},asetpts=PTS-STARTPTS,afade=t=in:d=0.03[m3];
[m1][m2][m3]concat=n=3:v=0:a=1[mus];
[2:v]fps=30,format=gray,lut=y='clip((val-5)*40\\,0\\,255)',erosion,boxblur=1:1[mt];
[0:v]fps=30,trim=0:3.8,setpts=PTS-STARTPTS,format=rgba[hd];
[hd][mt]alphamerge,format=yuva444p[p];
[base][g]overlay=format=auto:eof_action=pass[c1];
[c1][p]overlay=enable='between(t,{ORANGE_ON},{ORANGE_OFF})':eof_action=pass[c2];
[c2][gt]overlay=enable='between(t,{ORANGE_ON},{ORANGE_OFF})':eof_action=pass,format=yuv420p[v];
[voice][mus]amix=inputs=2:normalize=0:duration=first[a]
"""
    fc = re.sub(r"\n\s*", "", fc)
    cmd = ["ffmpeg", "-v", "error", "-y", "-i", p1, "-i", p2, "-i", cut, "-i", iA, "-i", iB, "-i", gfx,
           "-filter_complex", fc, "-map", "[v]", "-map", "[a]", "-t", f"{total:.3f}",
           "-c:v", "libx264", "-crf", "17", "-preset", "medium", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out]
    sh(cmd)
    sheet = os.path.join(os.path.expanduser("~"), "final_sheet.jpg")
    sh(["ffmpeg", "-v", "error", "-y", "-i", out, "-vf", "fps=1/2,scale=120:-1,tile=10x3",
        "-frames:v", "1", "-q:v", "5", sheet])
    print(json.dumps({
        "out": out, "duration": round(duration(out), 2),
        "part1_cut_after_studio": round(p1_end, 3), "graphics_cut1": round(cut1, 3),
        "land_word_at": round(land[0], 3) if land else None,
        "part2_graphics_offset": round(g3, 3), "part2_matched_words": len(offs),
        "insert_shift_frames": {"A": shiftA, "B": shiftB},
        "part1_has_studio": bool(studio), "part1_has_land": bool(land),
        "contact_sheet": sheet}, indent=1))


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    {"inspect": cmd_inspect, "prep": cmd_prep, "assemble": cmd_assemble}[sys.argv[1]](*sys.argv[2:])
