---
name: reels-revoice-higgsfield
description: Makes the "Fable 5.2 / Shorts Studio" promo reel (55 s, 9:16) starring the user — their face and their own voice — from three photos (front + left and right side) and a voice sample of up to 29 s. Uses the Higgsfield connector: Seedance 2.5 lip-sync re-voice, Genjutsu motion transfer, Genjutsu replace for the two editor-screen inserts, Higgsfield background removal for the orange card, then assembles the reel with the bundled alpha-channel graphics, captions and music in the Higgsfield sandbox. Use when someone attaches a photo and a voice recording and asks for "переозвучка", "сделай рилс со мной", "reels с моим лицом и голосом", "запусти скилл", or similar.
---

# Reels re-voice: your face + your voice in the Shorts Studio reel

The user sends **only**: this skill, **three photos of themselves** — front, left side, right side (face clearly visible, good even light, same outfit in all three; waist-up is best, because the outfit in the photos becomes the outfit in the video) — and **a voice recording of 10–29 s** (any clean speech, no music). **All three photos are required.** Every generation that puts the user into the video (step 4 and step 7) must get all three photos attached. If any of the three is missing, ask the user for it before spending any credits; do not start with fewer photos.
Everything else is inside this skill: the muted source video, the graphics with alpha, the music, the prompts, the timings and the assembly script.

Talk to the user in their language (usually Russian). Keep them posted with one short line per step.

## What you need

- The **Higgsfield connector** with these tools: `media_upload`, `media_confirm`, `media_import_url`, `generate_video`, `jobs_wait`, `remove_background`, `sandbox_exec`. If they are missing, tell the user to connect Higgsfield in Claude → Settings → Connectors and stop.
- About **2,600 credits** per reel: Seedance 2 × ~550, Genjutsu motion 2 × ~560, Genjutsu replace 2 × ~100, background removal is cheap. Check `balance` first and tell the user the estimate before the first paid call. The user's request to run the skill counts as the go-ahead; do not ask again for each step.
- Never pass `use_unlim` unless the user asks for it.

## Bundled sources (public URLs + copies in `assets/`)

Always use the URLs (the Higgsfield sandbox and `media_import_url` can fetch them directly). The files in `assets/` are identical copies kept for safety.

| What | URL | Local copy |
|---|---|---|
| Source video, part 1, muted (0–27.7 s) | https://d30d7anzgyxsrg.cloudfront.net/user_3FPIuukujZFxXBfDhcUbPeX0QPA/b17415ef-77cc-495a-8beb-64ad9fc71a98.mp4 | `assets/source_part1_muted.mp4` |
| Source video, part 2, muted (27.7–56.8 s) | https://d30d7anzgyxsrg.cloudfront.net/user_3FPIuukujZFxXBfDhcUbPeX0QPA/1d9a83e0-5285-4c47-9880-92003961629d.mp4 | `assets/source_part2_muted.mp4` |
| Graphics: colour on top, alpha below (1080×3840), music track inside | https://d30d7anzgyxsrg.cloudfront.net/user_3FPIuukujZFxXBfDhcUbPeX0QPA/ed07e858-4447-4ec3-b4ec-4e94e686227f.mp4 | `assets/graphics_color_alpha_stacked.mp4` |
| Editor-screen insert A template (graphics 4.47 s) | https://d30d7anzgyxsrg.cloudfront.net/user_3FPIuukujZFxXBfDhcUbPeX0QPA/375007e3-f5f0-4720-bcb7-d4e8d3f23eae.mp4 | `assets/insert_A_editor_template.mp4` |
| Editor-screen insert B template (graphics 21.5 s) | https://d30d7anzgyxsrg.cloudfront.net/user_3FPIuukujZFxXBfDhcUbPeX0QPA/72b710f3-46aa-4dcf-9cac-8f8c76b92c36.mp4 | `assets/insert_B_editor_template.mp4` |
| Word timings of the original speech | https://d30d7anzgyxsrg.cloudfront.net/user_3FPIuukujZFxXBfDhcUbPeX0QPA/8d6743b6-b062-497b-ac85-fadc90df9e5a.json | `data/original_word_timings.json` |
| Assembly script `reel.py` | https://d30d7anzgyxsrg.cloudfront.net/user_3FPIuukujZFxXBfDhcUbPeX0QPA/bc8ff7c1-02c6-4135-83aa-7955c2bce7e9.py | `scripts/reel.py` |

## Pipeline

Use `jobs_wait` to wait for generations (each Seedance / Genjutsu job takes ~5–15 min; launch independent jobs together and wait on them together). Keep every job id.

### 1. Get the user's photos and voice into Higgsfield
- Photos → `media_upload` (images, one batch), PUT the bytes, `media_confirm`. If you cannot read/PUT the attachments, call `media_upload_widget` (images, multiple) as the only tool in that turn and let the user upload there.
- Sort the three photos: `PHOTO_FRONT_ID` (both eyes visible, looking at the camera), `PHOTO_LEFT_ID`, `PHOTO_RIGHT_ID`. If there are not exactly three photos of the same person (front + two sides), stop and ask the user for the missing ones.
- Voice → same, as audio. Seedance needs **mp3/wav/m4a, ≤ 29 s**. If the file is `.ogg`/`.opus` or longer than 29 s, first convert/trim it to mp3 (ffmpeg in your own code environment, or upload it as-is and convert in the Higgsfield sandbox, then upload the mp3 from the sandbox). Note `VOICE_ID`.

### 2. Import the source parts
`media_import_url` (type video) for the two "Source video" URLs → `SRC1_ID`, `SRC2_ID`.
Also import the two insert templates now → `INS_A_TPL_ID`, `INS_B_TPL_ID`.

### 3. Seedance 2.5 lip-sync re-voice (two jobs, launch together)
`generate_video` with:
- `model: "seedance_2_5"`, `mode: "omni_reference"` (**not** `video_edit` — the user tested both, omni_reference is the one that works), `resolution: "1080p"`, `aspect_ratio: "9:16"`, `generate_audio: true`
- part 1: `duration: 28`, medias `[{role:"video_references", value: SRC1_ID}, {role:"audio_references", value: VOICE_ID}]`
- part 2: `duration: 29`, medias `[{role:"video_references", value: SRC2_ID}, {role:"audio_references", value: VOICE_ID}]`

Prompt part 1 (copy exactly):
```
Recreate the reference video exactly, frame for frame: same person, face, clothes, room, framing, cuts, camera angles, gestures and timing. Clean raw camera footage only: no text, no captions, no subtitles, no titles, no logos, no on-screen graphics, no UI windows, no screen recordings, no overlays, no picture-in-picture. The person talks to camera with the voice from the reference audio (same timbre, tone, pitch and accent), clean studio speech, no music, no other voices. The lips are perfectly synced to the speech. Pronunciation: the brand name Higgsfield is said clearly as "HIGGS-field" (like the Higgs boson, then the word field); the name Claude is said clearly as "KLAWD" (one syllable, like the name Claude). The person says only the script below, in English, word for word, without adding or changing any words: "Fable 5.2 just dropped and it edited this entire video in one click. You don't need After Effects or Premiere Pro, nothing. The captions, the cuts, the effects — were all done with just Claude and Higgsfield. And right now, Higgsfield is giving you three days of unlimited access to all models for free. I can make screen recordings appear as I explain, and even the sound effects land with the edits. It's called Shorts Studio,"
```

Prompt part 2 (copy exactly):
```
Recreate the reference video exactly, frame for frame: same person, face, clothes, room, framing, cuts, camera angles, gestures and timing. Clean raw camera footage only: no text, no captions, no subtitles, no logos, no on-screen graphics, no UI windows, no overlays. The person talks to camera with the voice from the reference audio (same timbre, tone, pitch and accent), clean studio speech, no music, no other voices. The lips are perfectly synced to the speech. Pronunciation: the brand name Higgsfield is said clearly as "HIGGS-field" (like the Higgs boson, then the word field); the name Claude is said clearly as "KLAWD" (one syllable, like the name Claude). The person says only the script below, in English, word for word, without adding or changing any words: "powered by Higgsfield, right inside your Claude. You can just upload your best performing video as a reference, or start with a proven template from Higgsfield. Type slash shorts in Claude, give it a topic, and show it the style you want. It creates the visuals for you — the images, the supporting footage, all built around your story. Editing this kind of video would take hours or even days with Adobe. I didn't even film the video you're watching right now. I just uploaded my photo and a script. Pretty good, isn't it? Comment short and I'll send you the link."
```

**Check both results before going on** (see "Sandbox setup" below for getting `reel.py`):
`python3 reel.py inspect <result_url> 1` (and `... 2`) in `sandbox_exec`, then look at the contact sheet with `image_paths: ["inspect_part1.jpg"]`.
- Regenerate the part if: the contact sheet shows **any text, captions, plates, UI windows** (Seedance sometimes draws its own captions — this happened in part 1 of the reference run), or `coverage` < 0.85, or many `extra_words` in the middle.
- Extra words **after "Studio"** at the end of part 1 are normal (Seedance ad-libs to fill the 28 s); `assemble` cuts them off automatically. Do not regenerate for that.
- Higgsfield / Claude are often transcribed as "Hicksfield" / "cloud" — that is fine.

### 4. Genjutsu motion transfer: put the user into both parts (two jobs together)
`generate_video` with `model: "hf_mult_motion_control"`, `resolution: "1080p"`, medias — **always all three photos** (front first, then both sides), then the video:
`[{role:"image_references", value: PHOTO_FRONT_ID}, {role:"image_references", value: PHOTO_LEFT_ID}, {role:"image_references", value: PHOTO_RIGHT_ID}, {role:"video_references", value: <Seedance job id of the part>}]`.
Never send this generation with fewer than three photos. If the call is rejected, fix the cause (e.g. re-upload a photo) and send it again with all three; if it still fails, stop and tell the user instead of falling back to one photo. Prompt:
```
Replace the person in the video with the person from the reference images (front view and side views of the same person: their face, hair and clothing). Keep the motion, gestures, lip movement, framing and cuts of the video exactly.
```
Genjutsu keeps the Seedance voice track; nothing else to do for audio. Call the results `GJ1_URL`, `GJ2_URL`.
It may change the room (darker / lighter); that is accepted.

**Check the Genjutsu results too** (timing safety): run `python3 reel.py inspect GJ1_URL 1` and `... GJ2_URL 2`.
- `duration` must be within ~0.3 s of the Seedance part (28 / 29 s) and `coverage` about the same as for the Seedance part. If Genjutsu cut the end off (part 2 must still end with "...send you the link"; part 1 must still contain "Studio"), regenerate that Genjutsu job.
- Small shifts in time do not matter: `assemble` finds the words in the Genjutsu result itself and places the cuts and the graphics by them, not by fixed seconds.
- Look at the contact sheet: the user's face in every shot, no captions.

### 5. Sandbox: cut-outs and references
In `sandbox_exec` run `python3 reel.py prep GJ1_URL GJ2_URL`. It writes:
- `~/head_3s8.mp4` — first 3.8 s of part 1 (for the orange card),
- `~/speaker_ref.jpg` — a talking-head frame of the user from part 2 (reference for the editor-screen inserts). Look at it with `image_paths`; if the face is turned away, extract another frame (`ffmpeg -ss <t> -i part2.mp4 -frames:v 1 speaker_ref.jpg`).

Upload both from the sandbox: call `media_upload` (one video, one image) first, then in one `sandbox_exec` command `curl -f -X PUT -H "Content-Type: ..." --upload-file <file> '<upload_url>'` for each, then `media_confirm`. → `HEAD_ID`, `REF_ID`.

### 6. Background removal for the orange card
`remove_background` with `{media_id: HEAD_ID, media_type: "video"}` → result URL `CUTOUT_URL` (person on black, no alpha — `assemble` builds the matte from it; do not key black, that would eat dark hair).

### 7. Editor-screen inserts with the user's face (two jobs together, launch together with step 6)
At graphics 4.5 s and 21.5 s a screen of the editing app appears; its previews show the original creator. Replace him with the user:
`generate_video` with `model: "hf_mult_replace_object"`, `resolution: "1080p"`, medias — the reel frame first, then **all three photos**, then the template:
`[{role:"image_references", value: REF_ID}, {role:"image_references", value: PHOTO_FRONT_ID}, {role:"image_references", value: PHOTO_LEFT_ID}, {role:"image_references", value: PHOTO_RIGHT_ID}, {role:"video_references", value: INS_A_TPL_ID}]` (then the same with `INS_B_TPL_ID`).
`REF_ID` (the frame from the reel) goes first because it sets the look of the previews: with only a studio photo the model once put a full-body lookbook shot into the previews; with the reel frame first they show the same talking head as the reel. The three photos are always attached as well, for the face. Never send this generation without them.
Prompt A:
```
Replace only the person shown inside the video previews of the editing software (large program monitor, small source monitor and media thumbnails) with the person from the reference images (the first image shows how they look in the reel; the other three are front and side photos of the same person), keeping each preview's framing: a talking-head shot of them sitting at a table in a room, same clothes as in the first reference, same pose and gestures as the original person. Do not change anything else: the dark editing software interface, all text, timeline, panels, cursors, colors, layout and motion stay exactly the same.
```
Prompt B: the same, but `all text including 'SCREEN RECORDINGS APPEAR'`.
The templates are padded to 4.2 s because Genjutsu needs ≥ 4 s; `assemble` uses only the needed frames. → `INS_A_URL`, `INS_B_URL`.

### 8. Assemble in the sandbox
Write `~/cfg.json`:
```json
{
 "part1": "GJ1_URL", "part2": "GJ2_URL",
 "head_cutout": "CUTOUT_URL",
 "insert_A": "INS_A_URL", "insert_B": "INS_B_URL",
 "insert_A_template": "https://d30d7anzgyxsrg.cloudfront.net/user_3FPIuukujZFxXBfDhcUbPeX0QPA/375007e3-f5f0-4720-bcb7-d4e8d3f23eae.mp4",
 "insert_B_template": "https://d30d7anzgyxsrg.cloudfront.net/user_3FPIuukujZFxXBfDhcUbPeX0QPA/72b710f3-46aa-4dcf-9cac-8f8c76b92c36.mp4",
 "graphics": "https://d30d7anzgyxsrg.cloudfront.net/user_3FPIuukujZFxXBfDhcUbPeX0QPA/ed07e858-4447-4ec3-b4ec-4e94e686227f.mp4",
 "word_timings": "https://d30d7anzgyxsrg.cloudfront.net/user_3FPIuukujZFxXBfDhcUbPeX0QPA/8d6743b6-b062-497b-ac85-fadc90df9e5a.json",
 "out": "final_reel.mp4"
}
```
Call `media_upload` for `final_reel.mp4` first, then run in the background on an XL sandbox (`background: true, size: "xl"`):
```
cd ~ && python3 reel.py assemble cfg.json && curl -f -X PUT -H "Content-Type: video/mp4" --upload-file final_reel.mp4 '<upload_url>'
```
Poll the log until it finishes (≈ 1–6 min), then `media_confirm`. Look at `final_sheet.jpg` with `image_paths`. Give the user the final URL.
Read the printed JSON: `part1_has_studio` and `part1_has_land` must be `true`, `part2_matched_words` should be ≥ 60. If not, the speech in that part is off — inspect it and regenerate the Seedance/Genjutsu part instead of shipping.
Reference values from the approved run: `part1_cut_after_studio` ≈ 25.9, `graphics_cut1` = 24.16, `part2_graphics_offset` ≈ 27.64, duration ≈ 55 s.

What `assemble` does (all of it is the user's approved edit of the reference reel):
- part 1 is cut right after the word "Studio" (drops Seedance's ad-lib), part 2 follows directly;
- graphics: kept 1:1 up to the moment the speaker says "land", but never before 24.16 s (the cut point the user chose by hand) and never after 25.10 s; from there it jumps straight to the "land with the edits" caption (graphics 25.10 s); part 2 graphics are placed by matching every spoken word to the original timing (median offset), so all captions sit on the words;
- the jump between parts happens under the full-screen white app screens, so it is invisible;
- orange card (0.23–3.6 s): the reel starts with the normal shot; while the card is on, the user is cut out over the orange and the card's captions stay on top of them;
- the two editor-screen inserts are replaced with the new ones, masked by the original alpha (rounded corners kept); if Genjutsu returned them shifted in time, the shift is detected against the templates and undone (`insert_shift_frames` in the output, normally 0);
- audio = new voice + the graphics' music/SFX, cut at the same points.

### 9. Deliver
Send the final URL (and the job ids), the duration and one line of what was checked. If something looks off, fix that step only — every step's output is reusable.

## Sandbox setup
Each `sandbox_exec` sandbox is per user and keeps `/home/user` for 24 h. Before the first `reel.py` call:
```
cd ~ && curl -fsSL -o reel.py https://d30d7anzgyxsrg.cloudfront.net/user_3FPIuukujZFxXBfDhcUbPeX0QPA/bc8ff7c1-02c6-4135-83aa-7955c2bce7e9.py
```
If that URL ever fails, recreate `~/reel.py` from `scripts/reel.py` of this skill with a heredoc.
If `sandbox_created: true` comes back later, the files are gone: download `reel.py` again (inputs are re-fetched by URL automatically).

## Lessons from the reference run (do not repeat)
- Seedance `video_edit` mode was rejected by the user; use `omni_reference`.
- Telling Seedance to "keep the captions / screen recordings / graphics" makes it **draw** them. The source parts are clean; the prompt must forbid any text or overlay.
- Seedance fills leftover seconds with invented phrases ("…and it's going to change the way you make videos"); never cut by fixed time, cut by the last scripted word — `assemble` does this.
- Higgsfield background removal returns black background, not alpha; build the matte from its luminance (`assemble` does it).
- The orange card's captions must stay above the cut-out person; areas without the card must stay transparent (an earlier version turned the first 0.3 s black).
- For the editor-screen inserts put a frame from the generated reel first, then the three photos; a photo alone as the only reference gave a lookbook shot instead of a talking head.
- Every generation that swaps the person (motion transfer and the inserts) always gets all three photos: front, left side, right side. Never one photo.
